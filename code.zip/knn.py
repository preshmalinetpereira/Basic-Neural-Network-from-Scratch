from statistics import mean, variance
from sklearn.model_selection import train_test_split
from scipy.spatial import distance
from sklearn import preprocessing
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import make_column_transformer
import csv
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import datasets

def readfile(filename):
    with open(filename, newline='') as file:
        data = pd.read_csv(filename)

    return data.to_numpy()

def normalizedata(data):
    ndata = data.copy()
    for i in range(len(data)):
        for j in range(len(data[i])):
            b = max(list(zip(*data))[j]) - min(list(zip(*data))[j])
            if data[i][j] != 0 and b != 0:
                print(b)
                ndata[i][j] = (data[i][j] - min(list(zip(*data))[j]))/b
    return ndata

def kNN(x_train, x_test, y_train, k):
    predictions = []
    for te in x_test:
        edist = []
        neighbors = []
        for tr, ytr in zip(x_train, y_train):
            l = distance.euclidean(te, tr)
            edist.append((l, ytr))
        edist.sort()
        for i in range(k):
            neighbors.append(edist[i][1])
        predictions.append(max(neighbors))
    return predictions

def stratifiedkfold(data, k):
    """The following code for the function is written by my team partner Linet Pereira"""
    classes = list(data[data.columns[-1]].value_counts().index)
    class_splits = {}
    for i in range(len(classes)):
        c = classes[i]
        splits = np.array_split(data[data[data.columns[-1]] == c].values.tolist(), k)
        class_splits[c] = splits

    stratified_splits = {}
    t = 0
    for i in range(k):
        combined = []
        for c in classes:
            t += len(class_splits[c][i])
            if len(combined) == 0:
                combined = class_splits[c][i]
            else:
                combined = np.vstack((combined, class_splits[c][i]))
        np.random.shuffle(combined)
        stratified_splits[i] = combined
    return stratified_splits

def get_splits(datasets, k, cols):
    """The following code for the function is written by my team partner Linet Pereira"""
    test = pd.DataFrame(datasets.pop(k),columns= cols)
    cols = test.columns
    X_test = test[test.columns[:-1]]
    y_test = test[test.columns[-1]]
    combined = []
    for j in datasets:
        if len(combined) == 0:
            combined = datasets[j]
        else:
            combined = np.concatenate((combined, datasets[j]), axis=0)
    train = pd.DataFrame(combined, columns=cols)
    X_train = train[cols[:-1]]
    y_train = train[cols[-1]]
    return X_train, y_train, X_test, y_test

def kNNfolds(data, kval, k):
    cols = data.columns
    k_data = stratifiedkfold(data, kval)

    acc, pr, re, f1 = [], [], [], []
    for i in range(kval):
        df = k_data.copy()
        x_train, y_train, x_test, y_test = get_splits(df, i, cols)
        x_train = normalizedata(x_train)
        x_test = normalizedata(x_test)
        predictions = kNN(x_train, x_test, y_train, k)
        a, pre, rec, f1s = multi_calculate_metrics(y_test, predictions, ['0','1','2','3','4','5','6','7','8','9'])
        acc.append(a)
        pr.append(pre)
        re.append(rec)
        f1.append(f1s)
    return mean(acc), mean(pr), mean(re), mean(f1)

def dataencoding(data, colnames, name):
    ohe = OneHotEncoder()
    df = pd.DataFrame(data)
    df.columns = colnames
    transformer = make_column_transformer((OneHotEncoder(), name), remainder='passthrough')
    transformed = transformer.fit_transform(df)
    transformed_df = pd.DataFrame(transformed, columns=transformer.get_feature_names())
    return transformed_df.values.tolist()

def std_calculate_metrics(actuals, preds, p=1):
    """The following code for the function is written by my team partner Linet Pereira"""
    TP,FP,TN,FN = [],[],[],[]
        
    for actual,pred in zip(actuals, preds):
        TP.append(actual ==p and actual == pred)
        TN.append(actual !=p and actual == pred)
        FP.append(actual !=p and actual != pred)
        FN.append(actual ==p and actual != pred)

    TP = TP.count(True)
    FP = FP.count(True)
    TN = TN.count(True)
    FN = FN.count(True)
    accuracy =(TP+TN)/(TP+FP+TN+FN)
    try:
        precision = TP/(TP+FP)
        recall = TP/(TP+FN)
        f1_score = (2*(precision*recall))/(precision+recall)
    except:
        if TP ==0 and FP == 0 or FN ==0:
            precision, recall, f1_score = 1,1,1
        else:
            precision, recall, f1_score = 0,0,0

    return accuracy, precision, recall, f1_score

def multi_calculate_metrics(actuals, preds, unq):
    """The following code for the function is written by my team partner Linet Pereira"""
    acc, pre, rec, f1 = [],[],[],[]
    for u in unq:
        accuracy, precision, recall, f1_score = std_calculate_metrics(actuals, preds, u)
        acc.append(accuracy)
        pre.append(precision)
        rec.append(recall)
        f1.append(f1_score)

    return mean(acc), mean(pre), mean(rec), mean(f1)

def plot(data):
    acclist = []
    karr = []
    std = []
    for k in range(1, 52, 2):
        acc = []
        for i in range(1):  
            a, pr, re, f1 = kNNfolds(data, 10, k)
            acc.append(a)
            print("a")
        acclist.append(mean(acc))
        std.append(math.sqrt(variance(acc)))
        karr.append(k)

    plt.errorbar(np.array(karr),np.array(acclist),yerr=np.array(std),marker='D')
    plt.xlabel("k values")
    plt.ylabel("Accuracy")
    plt.show()


def dataset1(k):
    digits, y = datasets.load_digits(return_X_y=True, as_frame=True)
    xd = digits.join(y, how='right')
    print(kNNfolds(xd, 10, k))
    plot(xd)

def dataset2(k):
    data = readfile('titanic.csv')
    colnames = ['Survived','Pclass','Sex','Age','Siblings/Spouses Aboard','Parents/Children Aboard','Fare']
    data = pd.DataFrame(dataencoding(data, colnames, ['Sex']))
    print(kNNfolds(data, 10, k))
    plot(data)

def dataset3(k):
    x = readfile('loan.csv')
    colnames = ['Gender','Married','Dependents','Education','Self_Employed','ApplicantIncome','CoapplicantIncome','LoanAmount','Loan_Amount_Term','Credit_History','Property_Area','Loan_Status']
    x = pd.DataFrame(dataencoding(x, colnames, ['Gender','Married','Dependents','Education','Self_Employed','Property_Area', 'Loan_Status']))
    print(kNNfolds(x, 10, k))
    plot(x)

def dataset4(k):
    xdata = pd.DataFrame(readfile('parkinsons.csv'))
    print(kNNfolds(xdata, 10, k))
    plot(xdata)

if __name__ == '__main__':
    k = 21
    dataset1(k)
    dataset2(k)
    dataset3(k)
    dataset4(k)
