from matplotlib import pyplot as plt
import numpy as np
import pandas as pd
from helper import writetofile
from nn import NN, predict
from sklearn.preprocessing import OneHotEncoder
from utils import  Kfold, get_datasets, multi_calculate_metrics, normalize_df, plot_graph, std_calculate_metrics


def main(k, lambd, alpha, verbose=False):
    files = get_datasets(False)
    for d in files:
        dataset_name = d["name"]
        print("-----{} Dataset------".format(d["name"]))
        data = d["file"]
        data = normalize_df(data)
        kfold = Kfold(k, data)
        metricsByFold =[]
        for i in kfold.foldrange:
            # print(f"For K = {i}")
            [X_train, y_train], [X_test,y_test] = kfold.get_splits(i)
            if verbose:
                print("Training set")
            #initialize NN
            network_params = [X_train.shape[0], 8, 16, 8, 1,1]


            trained_params = NN(X_train, y_train, network_params, lambd=lambd, alpha=alpha, epochs=5000)

            # 
            preds = predict(X_test, trained_params, y_test)
            truth = y_test

            unq = np.unique(truth)
            if len(unq)>2:
                acc, prec, rec, f1 = (multi_calculate_metrics(truth, preds, unq))
            else:
                acc, prec, rec, f1 = (std_calculate_metrics(truth, preds))
            metricsByFold.append([acc, prec, rec, f1])
            print("Accuracy for fold-{} is {}".format(i, acc))
            print("F1-Score for fold-{} is {}".format(i, f1))
        metrics = np.sum(np.array(metricsByFold), axis=0)/k

        # plot_graph([1,2,3,4,5,6,7,8,9,10], metricsByFold[0],"Accuracy Values per fold for "+{dataset_name}+" dataset", "k", "Accuracy")
        writetofile(network_params,f"Algorithm hyperparameters:{lambd}_{alpha} | Dataset: {dataset_name} | Accuracy:{metrics[0]} | F1 Score:{metrics[3]}")
        print(f"Accuracy:{metrics[0]} | Precision:{metrics[1]} | Recall:{metrics[2]} | F1 Score:{metrics[3]}")
    # plot_graph(n_tree, performance[0],"Accuracy Values per n_tree parameter for "+names[d]+" dataset", "n_tree", "Accuracy")
    # plot_graph(n_tree, performance[1],"Precision Values per n_tree parameter "+names[d]+" dataset", "n_tree", "Precision")
    # plot_graph(n_tree, performance[2],"Recall Values per n_tree parameter "+names[d]+" dataset", "n_tree", "Recall")
    # plot_graph(n_tree, performance[3],"F1 score Values per n_tree parameter "+names[d]+" dataset", "n_tree", "F1 Score")




if __name__ == '__main__':
    #hyperparameters
    k = 10
    lambd = 0.0001
    alpha=0.02
    main(k, lambd, alpha, True)

