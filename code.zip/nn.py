from matplotlib import pyplot as plt
import numpy as np

from helper import backward, cost_fn, forward, init_weights, update_parameters


def NN(X, y, network_params, lambd, alpha=0.01, epochs=3000, print_cost=True):
    np.random.seed(1)
    params = init_weights(network_params)
    cost_list = []

    for i in range(epochs):

        AL, caches = forward(X, params)

        cost = cost_fn(AL, y, caches, lambd)

        grads = backward(AL, y, lambd, caches, params)

        params = update_parameters(params, grads, alpha)


        cost_list.append(cost)

    return params


def predict(X, parameters, y):

    preds, caches = forward(X, parameters)
    labels = (preds >= 0.5) * 1
    # accuracy = np.mean(labels == y) * 100
    return labels.squeeze()
    # return f"The accuracy rate is: {accuracy:.2f}%."