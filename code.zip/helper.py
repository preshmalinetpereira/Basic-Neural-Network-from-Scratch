import numpy as np


# def linear_forward(A_p, W, b):
#     Z = np.dot(W, A_p) + b
#     cache = (A_p, W, b)

#     return Z, cache


def activation_forward(A_p, W, b):

    Z = np.dot(W, A_p) + b
    A = sigmoid(Z)
    cache = (A_p, W, Z, b)

    return A, cache


def forward(X, parameters):
    
    A = X                           
    caches = []                     
    L = len(parameters) // 2        

    for l in range(1, L+1):
        A_p = A
        A, cache = activation_forward(A_p, parameters["W" + str(l)], parameters["b" + str(l)])
        caches.append(cache)

    return A, caches



# def get_cost(AL, y):
#     m = y.shape[1]              
#     cost = 

#     return cost

def sigmoid_gradient(dA, Z):
    A= sigmoid(Z)
    dZ = dA * A * (1 - A)

    return dZ

def sigmoid(Z):
    A = 1 / (1 + np.exp(-Z))
    return A

# def backward(dZ, cache):
#     A_p, W, b = cache



def activation_backward(dA, cache):
    A_p, W, Z, b = cache
    dZ = sigmoid_gradient(dA, Z)
    m = A_p.shape[1]

    dW = (1 / m) * np.dot(dZ, A_p.T)
    db = (1 / m) * np.sum(dZ, axis=1, keepdims=True)
    dA_p = np.dot(W.T, dZ)

    return dA_p, dW, dZ, db


def backward(AL, y, lambd, caches, parameters):
    y = y.reshape(AL.shape)
    L = len(caches)
    grads = {}
    grads_weights={}

    dAL = np.divide(AL - y, np.multiply(AL, 1 - AL))
    for l in range(L, 0, -1):
        current_cache = caches[l - 1]
        if l == L:
            grads["dA" + str(l - 1)], grads["dW" + str(l)],  grads["dZ" + str(l)],grads["db" + str(l)] = activation_backward(
                dAL, current_cache)
        else:
            grads["dA" + str(l - 1)], grads["dW" + str(l)],  grads["dZ" + str(l)], grads["db" + str(l)] = activation_backward(
                grads["dA" + str(l)], current_cache)

    return grads

def update_parameters(parameters, grads, alpha):
    L = len(parameters) // 2

    for l in range(1, L + 1):
            parameters["W" + str(l)] = parameters[
                "W" + str(l)] - alpha * grads["dW" + str(l)]
            parameters["b" + str(l)] = parameters[
                "b" + str(l)] - alpha * grads["db" + str(l)]
    return parameters


def init_weights(dims):
    np.random.seed(1)               
    params = {}
    L = len(dims)            

    for l in range(1, L):           
        params["W" + str(l)] = np.random.randn(dims[l], dims[l-1]) * 0.01
        params["b" + str(l)] = np.zeros((dims[l], 1))

    return params

def cost_fn(y_true, y_pred, caches, lambd):
    cost = 0

    for y, y_hat in zip(y_true, y_pred):
        curr_cost = - np.multiply(y,np.log(1.e-6 +y_hat)) - np.multiply(1-y,np.log(1.e-6 +1-np.array(y_hat)))

        cost += curr_cost
    
    cost /= len(y_true)
    S=0
    for cache in caches:
            S+=np.sum(np.power(cache[1], 2))
    S = (lambd/(2*(len(y_true))))*S
    return (cost+S)

def writetofile(text1, text):
    with open('output.txt', 'a') as output:
        output.write("Neural Network Architecture: %s\n %s \n" %(text1, text))
        